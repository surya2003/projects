
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct variable 
{
    char *name; 
    int flag; 
    int value;

} Variable;

typedef enum 
{
    AND,
    OR,
    NAND,
    NOR,
    XOR,
    NOT,
    PASS,
    DECODER,
    MULTIPLEXER

} kind_t;

typedef struct gate 
{
    kind_t kind; 
    int size; 
    int *params;

} Gate;

const char *gate_names[] = 
{
    "AND",
    "OR",
    "NAND",
    "XOR",
    "NOR",
    "NOT",
    "PASS",
    "DECODER",
    "MULTIPLEXER"
};

typedef struct circuit
{
    int numberOfInputs;
    int *inputs;
    int numberOfOutputs;
    int *outputs;
    int numberOfVariables;
    Variable **vars;
    int numberOfGates;
    Gate **gates;
    
} Circuit;

int vSearch(const char *vari, Circuit *circ) 
{
    if (!circ) 
    {
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < circ->numberOfVariables; ++i) 
    {
        if (strcmp(vari, circ->vars[i]->name) == 0) 
        {
            return i;
        }
    }

    return -1;
}

int gSearch(int gate, Circuit *circ)
{
    if (!circ || !circ->gates) 
    {
        exit(EXIT_FAILURE);
    }

    if (gate >= 0 && gate < circ->numberOfGates) 
    {
        return gate;
    }

    return -1;
}

void freeTwo(Variable *var)
{
    if (!var) 
    {
        return;
    }

    free(var->name);
    free(var);
}

void freeThree(Gate *gate)
{
    if (!gate) 
    {
        return;
    }

    free(gate->params);
    free(gate);
}

void fCircuit(Circuit *circ) 
{
    if (!circ) 
    {
        return;
    }

    // Free outputs, inputs, gates, and vars
    free(circ->outputs);
    free(circ->inputs);

    for (int i = 0; i < circ->numberOfGates; ++i) 
    {
        freeThree(circ->gates[i]);
    }

    free(circ->gates);

    for (int i = 0; i < circ->numberOfVariables; ++i) 
    {
        freeTwo(circ->vars[i]);
    }

    free(circ->vars);

    free(circ);
}

Variable *vNewC(const char *name, Circuit *circ) 
{
    // Check for NULL parameters
    if (!name || !circ) 
    {
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the new variable
    Variable *var = malloc(sizeof(Variable));
    if (!var) 
    {
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the variable name
    var->name = malloc(strlen(name) + 1);
    if (!var->name) 
    {
        free(var);
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Copy the variable name
    strcpy(var->name, name);

    // Initialize the variable properties
    var->flag = 0;
    var->value = -1;

    return var;
}

int nVarAdd(const char *var_name, Circuit *circ) 
{
    // Check for NULL parameters
    if (!var_name || !circ)
        exit(EXIT_FAILURE);

    // Search for the variable
    int i = vSearch(var_name, circ);
    if (i == -1) 
    {
        // If the variable doesn't exist, add it to the circuit

        // Increment the number of variables in the circuit
        i = circ->numberOfVariables;

        // Allocate memory for the new array of variables
        Variable **new_vars = malloc((i + 1) * sizeof(Variable *));
        if (!new_vars) 
        {
            fCircuit(circ);
            exit(EXIT_FAILURE);
        }

        // Copy existing variables to the new array
        for (int j = 0; j < i; j++)
            new_vars[j] = circ->vars[j];

        // Create a new variable and add it to the array
        new_vars[i] = vNewC(var_name, circ);
        if (!new_vars[i]) 
        {
            free(new_vars);
            fCircuit(circ);
            exit(EXIT_FAILURE);
        }

        // Free the old array and update the circuit's variable array
        free(circ->vars);
        circ->vars = new_vars;
        circ->numberOfVariables++;
    }

    return i;
}


Circuit *newCircuit() 
{
    // Allocate memory for the new circuit
    Circuit *circ = (Circuit *)malloc(sizeof(Circuit));
    if (!circ) 
    {
        fprintf(stderr, "ERROR: No Memory\n");
        exit(EXIT_FAILURE);
    }

    // Initialize variables and gates to NULL
    circ->vars = NULL;
    circ->gates = NULL;

    // Set all entries to zero
    memset(circ, 0, sizeof(Circuit));

    // Add variable "1" with value 1
    int n = nVarAdd("1", circ);
    circ->vars[n]->value = 1;

    // Add variable "0" with value 0
    int x = nVarAdd("0", circ);
    circ->vars[x]->value = 0;

    // Add a placeholder variable "_"
    nVarAdd("_", circ);

    return circ;
}

Gate *createNewGate(kind_t kind, int n, int size, Circuit *circ) 
{
    // Check for NULL parameters
    if (!circ) 
    {
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the new gate
    Gate *gate = malloc(sizeof(Gate));
    if (!gate) 
    {
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the gate parameters
    gate->params = malloc(n * sizeof(int));
    if (!gate->params) 
    {
        free(gate);
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Initialize the gate properties
    gate->kind = kind;
    gate->size = size;

    // Initialize the gate parameters to -1
    for (int i = 0; i < n; i++) 
    {
        gate->params[i] = -1;
    }

    return gate;
}


Circuit *lCircuit(const char *filename) 
{
    // Check for NULL filename
    if (!filename) 
    {
        exit(EXIT_FAILURE);
    }

    char inVal[20];
    int i;
    int outer;
    int numberOuts;
    int n;
    int size;

    kind_t kind;

    Circuit *circ;

    Gate *gate;

    // Create a new circuit
    circ = newCircuit();

    // Open the file for reading
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) 
    {
        fprintf(stderr, "ERROR: Could not open file %s for reading circuit\n", filename);
        exit(EXIT_FAILURE);
    }

    // Read the number of inputs
    fscanf(fp, "%16s %d", inVal, &circ->numberOfInputs);

    // Check if the input format is correct
    if (strcmp(inVal, "INPUT") != 0) 
    {
        fprintf(stderr, "ERROR: Incorrect input format\n");
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the inputs
    circ->inputs = (int *)malloc(circ->numberOfInputs * sizeof(int));
    if (circ->inputs == NULL) 
    {
        fprintf(stderr, "ERROR: Memory allocation failed\n");
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Read input variable names and add them to the circuit
    i = 0;
    while (i < circ->numberOfInputs) 
    {
        if (fscanf(fp, "%16s", inVal) != 1) 
        {
            fCircuit(circ);
            exit(EXIT_FAILURE);
        }

        n = nVarAdd(inVal, circ);
        circ->inputs[i] = n;

        i++;
    }

    // Read the number of outputs
    fscanf(fp, "%16s %d", inVal, &circ->numberOfOutputs);

    // Check if the output format is correct
    if (strcmp(inVal, "OUTPUT") != 0) 
    {
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Allocate memory for the outputs
    circ->outputs = (int *)malloc(circ->numberOfOutputs * sizeof(int));
    if (circ->outputs == NULL) 
    {
        fCircuit(circ);
        exit(EXIT_FAILURE);
    }

    // Read output variable names and add them to the circuit
    int z = 0;
    while (z < circ->numberOfOutputs) 
    {
        if (fscanf(fp, "%16s", inVal) != 1) 
        {
            fCircuit(circ);
            exit(EXIT_FAILURE);
        }

        n = nVarAdd(inVal, circ);
        circ->outputs[z] = n;
        circ->vars[circ->outputs[z]]->flag = 1;

        z++;
    }

    // Read the gates from the file
    while (!feof(fp)) 
    {
        if (fscanf(fp, "%16s", inVal) == 1) 
        {
            numberOuts = 1;
            outer = 2;

            // Check the gate type
            if (strcmp(inVal, "PASS") == 0) 
            {
                kind = PASS;
                n = 2;
                outer = 1;
                numberOuts = 1;
            } 
            
            else if (strcmp(inVal, "NOT") == 0) 
            {
                kind = NOT;
                n = 2;
                outer = 1;

            } 
            
            else if (strcmp(inVal, "OR") == 0) 
            {
                kind = OR;
                n = 3;

            } 
            
            else if (strcmp(inVal, "AND") == 0) 
            {
                kind = AND;
                n = 3;

            } 
            
            else if (strcmp(inVal, "NAND") == 0) 
            {
                kind = NAND;
                n = 3;

            } 
            
            else if (strcmp(inVal, "XOR") == 0) 
            {
                kind = XOR;
                n = 3;

            } 
            
            else if (strcmp(inVal, "NOR") == 0) 
            {
                kind = NOR;
                n = 3;

            } 
            
            else if (strcmp(inVal, "DECODER") == 0) 
            {
                kind = DECODER;
                fscanf(fp, "%d", &size);
                n = size + (1 << size);
                outer = size;
                numberOuts = 1 << size;

            } 
            
            else if (strcmp(inVal, "MULTIPLEXER") == 0) 
            {
                kind = MULTIPLEXER;
                fscanf(fp, "%d", &size);
                n = size + (1 << size) + 1;
                outer = size + (1 << size);
                numberOuts = 1;

            } 
            
            else 
            {
                fprintf(stderr, "ERROR: Unknown gate type\n");
                fCircuit(circ);
                fclose(fp);
                exit(EXIT_FAILURE);
            }

            // Create a new gate
            gate = createNewGate(kind, n, size, circ);

            // Read input variable names and add them to the gate
            i = 0;
            int w;
            while (i < n) 
            {
                if (fscanf(fp, "%16s", inVal) != 1) 
                {
                    printf("%s", gate_names[kind]);
                    fCircuit(circ);
                    freeThree(gate);
                    fclose(fp);
                    exit(EXIT_FAILURE);
                }

                w = nVarAdd(inVal, circ);
                gate->params[i] = w;
                if (i >= outer && i < outer + numberOuts && circ->vars[w]->flag == 0)
                    circ->vars[w]->flag = 1;

                i++;
            }

            // Add the gate to the circuit
            if (circ == NULL || gate == NULL) 
            {
                fCircuit(circ);
                fclose(fp);
                exit(EXIT_FAILURE);
            }
            Gate **new_gates = malloc((circ->numberOfGates + 1) * sizeof(Gate *));

            for (int i = 0; i < circ->numberOfGates; i++) 
            {
                new_gates[i] = circ->gates[i];
            }

            new_gates[circ->numberOfGates] = gate;

            free(circ->gates);

            circ->gates = new_gates;

            circ->numberOfGates++;
        }
    }

    fclose(fp);

    return circ;
}


int decVal(int first, int last, const Gate *gate, const Circuit *circ) 
{
    int val = 0;
    int pow = 0;

    for (int i = last; i >= first; i--) 
    {
        if (circ->vars[gate->params[i]]->value != -1) 
        {
            val += circ->vars[gate->params[i]]->value << pow;
        } 
        
        else 
        {
            val = -1;
            break;
        }

        pow++;
    }

    return val;
}

int gDet(Gate *gate, Circuit *circ) 
{
    int t = circ->vars[gate->params[0]]->value;
    int f = circ->vars[gate->params[1]]->value;
    int result = -1;
    int temp;

    int flag = t != -1 && f != -1;
    int flag2 = t != -1;

    switch (gate->kind) 
    {
        case AND:
            if (flag) result = t & f;
            circ->vars[gate->params[2]]->value = result;
            break;
        
        case OR:
            if (flag) result = t | f;
            circ->vars[gate->params[2]]->value = result;
            break;
        
        case NOR:
            if (flag) result = (~(t | f)) & 1;
            circ->vars[gate->params[2]]->value = result;
            break;
        
        case NAND:
            if (flag) result = (~(f & t)) & 1;
            circ->vars[gate->params[2]]->value = result;
            break;
        
        case XOR:
            if (flag) result = t ^ f;
            circ->vars[gate->params[2]]->value = result;
            break;
        
        case NOT:
            if (flag2) result = (~t) & 1;
            circ->vars[gate->params[1]]->value = result;
            break;
        
        case PASS:
            result = t;
            circ->vars[gate->params[1]]->value = result;
            break;
        
        case MULTIPLEXER:
            
            temp = decVal(1 << gate->size, (1 << gate->size) + gate->size - 1, gate, circ);
            
            if (temp == -1) 
            {
                circ->vars[gate->params[(1 << gate->size) + gate->size]]->value = -1;
            } 
            
            else 
            {
                result = circ->vars[gate->params[temp]]->value;
                circ->vars[gate->params[(1 << gate->size) + gate->size]]->value = result;
            }

            break;
        
        case DECODER:
            
            temp = decVal(0, gate->size - 1, gate, circ);
            if (temp == -1) 
            {
                for (int i = 0; i < (1 << gate->size); i++) 
                {
                    circ->vars[gate->params[gate->size + i]]->value = -1;
                }
            } 
            
            else 
            {
                for (int i = 0; i < (1 << gate->size); i++) 
                {
                    circ->vars[gate->params[gate->size + i]]->value = 0;
                }

                circ->vars[gate->params[gate->size + temp]]->value = 1;
                result = 1;
            }

            break;
    }

    return result;
}

void printInputs(Circuit *circ) 
{
    for (int i = 0; i < circ->numberOfInputs; i++) 
    {
        printf("%d ", circ->vars[circ->inputs[i]]->value);
    }
}

// Function to print outputs
void printOutputs(Circuit *circ) 
{
    for (int i = 0; i < circ->numberOfOutputs; i++) 
    {
        printf(" %d", circ->vars[circ->outputs[i]]->value);
    }
}

// Function to generate the next input combination
int nextInput(Circuit *circ) 
{
    int i = circ->numberOfInputs - 1;
    
    while (i >= 0) 
    {
        if (circ->vars[circ->inputs[i]]->value == 0) 
        {
            circ->vars[circ->inputs[i]]->value = 1;
            break;

        } 
        
        else if (circ->vars[circ->inputs[i]]->value == 1) 
        {
            circ->vars[circ->inputs[i]]->value = 0;
        }
        i--;
    }
    return i < 0;
}

// Function to reset output values
void resetOutputs(Circuit *circ) 
{
    for (int i = 0; i < circ->numberOfVariables; i++) 
    {
        if (circ->vars[i]->flag) 
        {
            circ->vars[i]->value = -1;
        }
    }
}

// Function to check if all outputs are valid
int validateOutputs(Circuit *circ) 
{
    int allOutputsValid = 1;
    
    for (int i = 0; i < circ->numberOfOutputs && allOutputsValid; i++) 
    {
        if (circ->vars[circ->outputs[i]]->value == -1) 
        {
            allOutputsValid = 0;
        }
    }

    return allOutputsValid;
}

// Function to evaluate the circuit
void circuitEvaluate(Circuit *circ) 
{
    int carry = 0;

    for (int i = 0; i < circ->numberOfInputs; i++) 
    {
        circ->vars[circ->inputs[i]]->value = 0;
    }

    for (int i = 0; !carry; i++) 
    {
        printInputs(circ);

        // Reset all outputs to -1
        resetOutputs(circ);

        for (int j = 0; !validateOutputs(circ); j++) 
        {
            for (int k = 0; k < circ->numberOfGates; k++) 
            {
                gDet(circ->gates[k], circ);
            }
        }

        printf("|");
        printOutputs(circ);
        printf("\n");

        carry = nextInput(circ);
    }
}

int main(int argc, char **argv) 
{
    Circuit *circ;

    if (argc != 2) 
    {
        printf("Incorrect number of arguments\n");
        return EXIT_FAILURE;
    }

    // Error checking
    if (argv[1] == NULL) 
    {
        printf("Error: No file name given\n");
        return EXIT_FAILURE;
    }

    circ = lCircuit(argv[1]);
    circuitEvaluate(circ);
    fCircuit(circ);

    return EXIT_SUCCESS;
}